/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 * Nombre : Jorge Alexander Castillo Niño
 * Fecha : 07/03/2024
 * Tema : Listas Doblemente Enlazadas
 */
public class Estudiante {
    //Declaración de variables
    String nombre;
    int edad;
    //Metodo Construtor
    public Estudiante(String nombre, int edad) {
        //Inicializar variabless
        this.nombre = nombre;
        this.edad = edad;
        
    }
    

}
