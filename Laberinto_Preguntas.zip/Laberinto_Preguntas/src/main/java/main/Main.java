package main;

import controller.Controlador;






/**
 * Nombre: Jorge Alexander Castillo Niño Jorge Alejandro Arias Trujillo
 * Fecha : 29/02/2024
 * Tema : Laberinto
*/
  
public class Main {
    //Metodo Main
    public static void main(String[] args) {
        Controlador controlador = new Controlador();
        controlador.iniciarJuego();
    }
}
